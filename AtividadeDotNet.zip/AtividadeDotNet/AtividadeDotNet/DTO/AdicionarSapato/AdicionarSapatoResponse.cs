﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AtividadeDotNet.DTO.AdicionarSapato
{
    public class AdicionarSapatoResponse
    {
        public string msg { get; set; }
    }
}
