﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AtividadeDotNet.DTO.AtualizarSapato
{
    public class AtualizarSapatoResponse
    {
        public string msg { get; set; }
    }
}
