﻿using AtividadeDotNet.Bordas.Adapter;
using AtividadeDotNet.Bordas.Repositorios;
using AtividadeDotNet.DTO.AdicionarSapato;
using AtividadeDotNet.Entities;
using AtividadeDotNet.UseCase;
using Moq;
using Xunit;

namespace AtividadeDotNetTeste.UseCase
{
    public class AdicionarSapatoUseCaseTest
    {
        private readonly Mock<IRepositorioSapatos> _repositoriosSapatos;
        private readonly Mock<IAdicionarSapatoAdapter> _adicionarSapatoAdapter;
        private readonly AdicionarSapatoUseCase _useCase;

        public AdicionarSapatoUseCaseTest()
        {
            _repositoriosSapatos = new Mock<IRepositorioSapatos>();
            _adicionarSapatoAdapter = new Mock<IAdicionarSapatoAdapter>();
            _useCase = new AdicionarSapatoUseCase(_repositoriosSapatos.Object, _adicionarSapatoAdapter.Object);
        }

        [Fact]
        public void Sapato_AdicionarSapato_QuandoRetornarSucesso() 
        {
            var request  = new AdicionarSapatoRequest();
            var response = new AdicionarSapatoResponse();
            var sapato   = new Sapato();
            var sapatoId = 1;
            _repositoriosSapatos.Setup(repositorio => repositorio.Add(sapato)).Returns(sapatoId);
            _adicionarSapatoAdapter.Setup(adapter => adapter.converterResquesteParaSapato(request)).Returns(sapato);
        }
    }
}
